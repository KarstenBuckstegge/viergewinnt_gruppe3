package logic;

public class LineCheck {

}
