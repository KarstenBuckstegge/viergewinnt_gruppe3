package logic;

public class KI {
	public static void checkThreeRow() {
		System.out.println(Field.field [3][3]);
	}
}
