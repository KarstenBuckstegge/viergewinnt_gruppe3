package connect;

import java.io.IOException;

public class Test {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Test gestartet!");
		
		Connect.setStone(5);
		
		System.out.println("Test beendet, jetzt die Textdatei im Stammverzeichnis pr�fen!");
		
		
		
	}

}
